# -*- coding: utf-8 -*-

from __future__ import print_function
import os
import numpy as np
import Qmaze_
import maze_
import qtrain_
import time

maze = maze_.temp_maze
env = maze_.env


def play_game(model, qmaze, rat_cell):

    qmaze.reset(rat_cell) # 입력 받은 위치로 로봇을 맵에 초기화함
    envstate = qmaze.observe() # 현재 스테이트를 받아옴

    while True:
        prev_envstate = envstate # 스테이트를 전환

        # get next action
        q = model.predict(prev_envstate) # 스테이트를 넣고 q 배열이 나옴
        action = np.argmax(q[0]) # 큰 Q 벨류가 액션

        # apply action, get rewards and new state
        env.step(action)  # 액션 취함
        env.render()

        time.sleep(0.1)

        envstate, reward, game_status = qmaze.act(action)

        if game_status == 'win': # 목적지에 도착하면
            print("win")  # win
            return True # true

        elif game_status == 'lose': # 갈 곳이 없으면
            print("lose") # lose
            return False # false


if __name__ == "__main__":

    # env = maze_.Maze()
    print("0: 새로 학습 1: 기존 것에 학습 2: 학습 결과 보기")
    a = input()
    if (a=='0'):
        # Load the model from disk
        model = qtrain_.build_model(maze)

        # Train by playing the game - change visualize to True to also visualize the training
        qtrain_.qtrain(model, maze, epochs=1000, max_memory=8 * maze.size, data_size=32)

        # Save the model
        model.save('model.h5')

        # load model
        model = qtrain_.build_model(maze)
        model.load_weights('model.h5')

        while True:
            play_game(model, Qmaze_.Qmaze(maze), (0, 0))  # 0의 위치에서 게임 시작
            env.reset()  # 리셋

        env.mainloop()  # 창 지속

    elif(a=='1'):
        # Load the model from disk
        model = qtrain_.build_model(maze)

        # 기존 것에 더 학습
        qtrain_.qtrain(model, maze, epochs=1000, max_memory=8 * maze.size, data_size=32, weights_file="model.h5")
        model.save('model.h5')

        # load model
        model = qtrain_.build_model(maze)
        model.load_weights('model.h5')

        while True:
            play_game(model, Qmaze_.Qmaze(maze), (0, 0))  # 0의 위치에서 게임 시작
            env.reset()  # 리셋

        env.mainloop()  # 창 지속

    elif(a=='2'):
        # load model
        model = qtrain_.build_model(maze)
        model.load_weights('model.h5')

        while True:
            #print(maze_.maze)
            play_game(model, Qmaze_.Qmaze(maze_.maze), (0, 0)) #0의 위치에서 게임 시작
            env.reset() # 리셋

        env.mainloop()  # 창 지속


    # # Check if there is a pre-trained model
    # if not os.path.exists('model.h5'):
    #     # Load the model from disk
    #     model = qtrain_.build_model(maze)
    #
    #     # Train by playing the game - change visualize to True to also visualize the training
    #     qtrain_.qtrain(model, maze, epochs=1000, max_memory=8 * maze.size, data_size=32)
    #
    #     # Save the model
    #     model.save('model.h5')
    # else:
    #     # Load the model from disk
    #     model = qtrain_.build_model(maze)
    #
    #     # 기존 것에 더 학습
    #     qtrain_.qtrain(model, maze, epochs=1000, max_memory=8 * maze.size, data_size=32, weights_file="model.h5")
    #     model.save('model.h5')
    #
    #     # # load model
    #     # model.load_weights('model.h5')
    #     #
    #     # while True:
    #     #     play_game(model, Qmaze_.Qmaze(maze), (0, 0)) # 0의 위치에서 게임 시작
    #     #     env.reset() # 리셋
    #     #
    #     # env.mainloop()  # 창 지속




